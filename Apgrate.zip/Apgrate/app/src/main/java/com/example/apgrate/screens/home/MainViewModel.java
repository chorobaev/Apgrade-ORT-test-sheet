package com.example.apgrate.screens.home;

import androidx.lifecycle.ViewModel;

public class MainViewModel extends ViewModel {


}
