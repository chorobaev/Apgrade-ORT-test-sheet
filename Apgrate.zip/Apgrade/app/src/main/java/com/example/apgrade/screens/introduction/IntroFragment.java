package com.example.apgrate.screens.introduction;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.apgrate.R;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class IntroFragment extends Fragment {

    public static final String INTRO_IMAGE = "SlideImage";
    public static final String INTRO_MESSAGE = "SlideMessage";
    private int mImage;
    private String mMessage;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mImage = getArguments().getInt(INTRO_IMAGE);
        mMessage = getArguments().getString(INTRO_MESSAGE);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.introduction_fragment, container, false);
        ImageView imageView = v.findViewById(R.id.iv_icon);
        imageView.setImageResource(mImage);
        TextView textView = v.findViewById(R.id.tv_message);
        textView.setText(mMessage);

        return v;
    }

    public static Fragment getInstance() {
        return new IntroFragment();
    }
}
