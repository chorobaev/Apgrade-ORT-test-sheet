package com.example.apgrate.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.apgrate.BuildConfig;

import static android.content.Context.MODE_PRIVATE;

public class CommonUtils {

}
