package com.example.apgrate.screens.introduction;

import android.os.Bundle;

import com.example.apgrate.R;
import com.github.paolorotolo.appintro.AppIntro;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class IntroActivity extends AppIntro {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle bundle = new Bundle();
        bundle.putInt(IntroFragment.INTRO_IMAGE, R.drawable.logo);
        bundle.putString(IntroFragment.INTRO_MESSAGE, "It is Ramis");

        Fragment fragment = IntroFragment.getInstance();
        fragment.setArguments(bundle);
        addSlide(fragment);
    }
}
